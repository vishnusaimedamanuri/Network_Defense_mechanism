import { ATTACK_TYPES } from './types.js';
import { generateRandomIP, log } from './utils.js';

class AttackSimulator {
  constructor() {
    this.attacks = [
      this.simulatePortScan.bind(this),
      this.simulateDoS.bind(this),
      this.simulateBruteForce.bind(this)
    ];
  }

  simulatePortScan() {
    const ports = Array(Math.floor(Math.random() * 20) + 1)
      .fill(0)
      .map(() => Math.floor(Math.random() * 65535));

    return {
      type: ATTACK_TYPES.PORT_SCAN,
      data: { ports }
    };
  }

  simulateDoS() {
    return {
      type: ATTACK_TYPES.DOS,
      data: { requestsPerMinute: Math.floor(Math.random() * 200) + 50 }
    };
  }

  simulateBruteForce() {
    return {
      type: ATTACK_TYPES.BRUTE_FORCE,
      data: { failedLogins: Math.floor(Math.random() * 10) + 1 }
    };
  }

  generateAttack() {
    const ip = generateRandomIP();
    const attack = this.attacks[Math.floor(Math.random() * this.attacks.length)]();
    return { ip, attack };
  }

  start() {
    setInterval(() => {
      const { ip, attack } = this.generateAttack();
      log('INFO', `Simulating attack from ${ip}`, attack);
      process.send?.({ ip, attack });
    }, 2000);
  }
}

// Start the attack simulator
const simulator = new AttackSimulator();
simulator.start();
import { createServer } from 'net';
import chalk from 'chalk';
import { ATTACK_TYPES, DEFENSE_ACTIONS } from './types.js';
import { log } from './utils.js';

class NetworkDefender {
  constructor() {
    this.blockedIPs = new Set();
    this.suspiciousActivity = new Map();
    this.thresholds = {
      requestsPerMinute: 100,
      failedLogins: 5,
      portScans: 10
    };
  }

  detectAttack(ip, activity) {
    const { type, data } = activity;
    
    if (this.blockedIPs.has(ip)) {
      return null;
    }

    switch (type) {
      case ATTACK_TYPES.PORT_SCAN:
        return this.handlePortScan(ip, data);
      case ATTACK_TYPES.DOS:
        return this.handleDoS(ip, data);
      case ATTACK_TYPES.BRUTE_FORCE:
        return this.handleBruteForce(ip, data);
      default:
        return null;
    }
  }

  handlePortScan(ip, { ports }) {
    if (ports.length > this.thresholds.portScans) {
      return {
        action: DEFENSE_ACTIONS.BLOCK_IP,
        reason: `Port scan detected: ${ports.length} ports scanned`
      };
    }
    return null;
  }

  handleDoS(ip, { requestsPerMinute }) {
    if (requestsPerMinute > this.thresholds.requestsPerMinute) {
      return {
        action: DEFENSE_ACTIONS.RATE_LIMIT,
        reason: `DoS attack detected: ${requestsPerMinute} requests/minute`
      };
    }
    return null;
  }

  handleBruteForce(ip, { failedLogins }) {
    if (failedLogins > this.thresholds.failedLogins) {
      return {
        action: DEFENSE_ACTIONS.BLOCK_IP,
        reason: `Brute force attack detected: ${failedLogins} failed login attempts`
      };
    }
    return null;
  }

  defend(ip, attack) {
    const detection = this.detectAttack(ip, attack);
    
    if (!detection) {
      return;
    }

    const { action, reason } = detection;

    switch (action) {
      case DEFENSE_ACTIONS.BLOCK_IP:
        this.blockedIPs.add(ip);
        log('DEFENSE', `Blocked IP ${ip}`, { reason });
        break;
      case DEFENSE_ACTIONS.RATE_LIMIT:
        log('DEFENSE', `Rate limited IP ${ip}`, { reason });
        break;
      case DEFENSE_ACTIONS.INCREASE_MONITORING:
        log('DEFENSE', `Increased monitoring for IP ${ip}`, { reason });
        break;
    }
  }
}

// Start the defender
console.log(chalk.green('=== Network Defense Terminal ==='));
console.log(chalk.cyan('Monitoring for incoming attacks...'));

const defender = new NetworkDefender();
const server = createServer((socket) => {
  socket.on('data', (data) => {
    const { ip, attack } = JSON.parse(data.toString());
    log('ATTACK', `Incoming attack from ${ip}`, attack);
    defender.defend(ip, attack);
  });
});

server.listen(3000);
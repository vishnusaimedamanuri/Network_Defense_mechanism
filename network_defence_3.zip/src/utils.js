import { format } from 'date-fns';
import chalk from 'chalk';

export function generateRandomIP() {
  return Array(4).fill(0).map(() => Math.floor(Math.random() * 256)).join('.');
}

export function log(type, message, data = {}) {
  const timestamp = format(new Date(), 'yyyy-MM-dd HH:mm:ss');
  const colors = {
    ATTACK: chalk.red,
    DEFENSE: chalk.green,
    INFO: chalk.blue
  };

  console.log(
    `[${timestamp}] ${colors[type](type)}: ${message}`,
    Object.keys(data).length ? data : ''
  );
}
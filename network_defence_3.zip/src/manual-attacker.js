import readline from 'readline';
import { createServer } from 'net';
import net from 'net';
import chalk from 'chalk';
import { ATTACK_TYPES } from './types.js';
import { generateRandomIP, log } from './utils.js';

// Create TCP server for communication with defender
const client = createServer();
const PORT = 3000;

// Create interface for command line input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function displayMenu() {
  console.log('\nAvailable attacks:');
  console.log('1. Port Scan');
  console.log('2. DoS Attack');
  console.log('3. Brute Force');
  console.log('4. Generate Random IP');
  console.log('5. Exit');
  rl.question('\nSelect attack type (1-5): ', handleAttackChoice);
}

function sendAttack(ip, attack) {
  const data = JSON.stringify({ ip, attack });
  const client = new net.Socket();
  
  client.connect(PORT, 'localhost', () => {
    client.write(data);
    client.end();
  });
  
  log('INFO', `Attack sent from ${ip}`, attack);
}

function handleAttackChoice(choice) {
  let ip = global.currentIP || generateRandomIP();
  let attack;

  switch (choice) {
    case '1':
      attack = {
        type: ATTACK_TYPES.PORT_SCAN,
        data: {
          ports: Array(15).fill(0).map(() => Math.floor(Math.random() * 65535))
        }
      };
      break;

    case '2':
      attack = {
        type: ATTACK_TYPES.DOS,
        data: {
          requestsPerMinute: 150
        }
      };
      break;

    case '3':
      attack = {
        type: ATTACK_TYPES.BRUTE_FORCE,
        data: {
          failedLogins: 8
        }
      };
      break;

    case '4':
      global.currentIP = generateRandomIP();
      console.log(`New IP generated: ${global.currentIP}`);
      displayMenu();
      return;

    case '5':
      rl.close();
      process.exit(0);
      return;

    default:
      console.log('Invalid choice. Please try again.');
      displayMenu();
      return;
  }

  sendAttack(ip, attack);
  displayMenu();
}

console.log(chalk.yellow('=== Network Attack Terminal ==='));
console.log(chalk.cyan(`Current IP: ${global.currentIP || generateRandomIP()}`));
displayMenu();
import { fork } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));

// Start defender process
const defender = fork(resolve(__dirname, 'defender.js'));

// Start attacker process
const attacker = fork(resolve(__dirname, 'attacker.js'));

// Forward messages from attacker to defender
attacker.on('message', (message) => {
  defender.send(message);
});

// Handle process termination
process.on('SIGINT', () => {
  defender.kill();
  attacker.kill();
  process.exit();
});